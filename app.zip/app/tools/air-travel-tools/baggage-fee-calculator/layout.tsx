import type { Metadata } from "next";

import { createToolMetadata } from "@/app/lib/seo/metadata";
import { toolSEO } from "@/app/lib/seo/tools";

import ToolSchema from "@/app/components/seo/ToolSchema";
import BreadcrumbSchema from "@/app/components/seo/BreadcrumbSchema";

const seo = toolSEO["baggage-fee-calculator"];

export const metadata: Metadata = createToolMetadata({
    title: seo.title,
    description: seo.description,
    keywords: [...seo.keywords],
    category: seo.category,
    path: seo.path,
});

export default function BaggageFeeCalculatorLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const url = `https://www.inteliglo.com${seo.path}`;

    return (
        <>
            <ToolSchema
                name={seo.name}
                description={seo.description}
                url={url}
                category={seo.applicationCategory}
            />

            <BreadcrumbSchema
                items={[
                    {
                        name: "Home",
                        url: "https://www.inteliglo.com",
                    },
                    {
                        name: "Tools",
                        url: "https://www.inteliglo.com/tools",
                    },
                    {
                        name: "Air Travel Tools",
                        url: "https://www.inteliglo.com/tools/air-travel-tools",
                    },
                    {
                        name: seo.name,
                        url,
                    },
                ]}
            />

            {children}
        </>
    );
}