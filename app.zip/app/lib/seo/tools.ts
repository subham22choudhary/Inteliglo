export const toolSEO = {
    "baggage-fee-calculator": {
        name: "Baggage Fee Calculator",

        title: "Baggage Fee Calculator – Calculate Excess Baggage Fees",

        description:
            "Calculate airline excess baggage fees based on your baggage weight and airline. Get an instant estimate of additional baggage charges.",

        keywords: [
            "baggage fee calculator",
            "excess baggage calculator",
            "airline baggage fee calculator",
            "extra baggage calculator",
            "flight baggage fee calculator",
            "airline excess baggage charges",
        ],

        category: "Travel Tools",

        applicationCategory: "TravelApplication",

        path: "/tools/air-travel-tools/baggage-fee-calculator",
    },

    "currency-converter": {
        name: "Currency Converter",

        title: "Currency Converter – Convert Currencies Online",

        description:
            "Convert currencies quickly and easily with Inteliglo's free online currency converter.",

        keywords: [
            "currency converter",
            "currency conversion",
            "online currency converter",
            "money converter",
            "exchange rate calculator",
            "currency calculator",
        ],

        category: "Travel Tools",

        applicationCategory: "FinanceApplication",

        path: "/tools/air-travel-tools/currency-converter",
    },

    "layover-time-calculator": {
        name: "Layover Time Calculator",

        title: "Layover Time Calculator – Calculate Flight Connection Time",

        description:
            "Calculate flight layover and connection times easily. Find out how much time you have between connecting flights.",

        keywords: [
            "layover time calculator",
            "flight layover calculator",
            "connection time calculator",
            "airport layover calculator",
            "flight connection time calculator",
            "layover calculator",
        ],

        category: "Travel Tools",

        applicationCategory: "TravelApplication",

        path: "/tools/air-travel-tools/layover-time-calculator",
    },

    "visa-fee-calculator": {
        name: "Visa Fee Calculator",

        title: "Visa Fee Calculator – Calculate Visa Costs",

        description:
            "Estimate visa application fees and travel visa costs with Inteliglo's free visa fee calculator.",

        keywords: [
            "visa fee calculator",
            "visa cost calculator",
            "visa application fee calculator",
            "travel visa calculator",
            "visa charges calculator",
            "visa price calculator",
        ],

        category: "Travel Tools",

        applicationCategory: "TravelApplication",

        path: "/tools/air-travel-tools/visa-fee-calculator",
    },
} as const;